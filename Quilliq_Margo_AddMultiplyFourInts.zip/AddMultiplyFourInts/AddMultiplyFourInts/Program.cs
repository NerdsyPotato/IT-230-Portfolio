﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddMultiplyFourInts
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 13, b = 55, c = 123, d = 325; //Deciding the variables and the set of values listed
            int sum = a + b + c + d; //This provides the sum of the set numbers
            int product = a * b * c * d; //This provides the product of the set numbers
            //Print out the desired result
            Console.WriteLine("Margo Quilliq\n\nIT 230\n\n07/08/2024\n\n");
            Console.WriteLine("The sum of {0}, {1}, {2}, and {3} = {4} ", a, b, c, d, sum);
            Console.WriteLine("The product of {0}, {1}, {2}, and {3} = {4} ", a, b, c, d, product);

            Console.ReadLine();
        }
    }
}
